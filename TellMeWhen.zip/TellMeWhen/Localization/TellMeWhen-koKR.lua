﻿--[[ Credit for these translations goes to:
	sunyruru
--]]
local L = LibStub("AceLocale-3.0"):NewLocale("TellMeWhen", "koKR", false)
if not L then return end


--@localization(locale="koKR", format="lua_additive_table", handle-unlocalized="ignore")@


