﻿--[[ Credit for these translations goes to:
	TomHB
	fiesekeule
	Quevain
	XNuclearWinterX
	erwinmeier
	xevilgrin
	Farronski
--]]
local L = LibStub("AceLocale-3.0"):NewLocale("TellMeWhen", "deDE", false)
if not L then return end


--@localization(locale="deDE", format="lua_additive_table", handle-unlocalized="ignore")@