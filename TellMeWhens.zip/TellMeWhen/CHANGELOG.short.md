
## v8.7.5
* #1787 - Added Vulpera and Mechagnomes to Unit Race condition.
* #1784 - Let OmniCC detect charge-type cooldowns 

### Bug Fixes
* Fix #1764 - Fix resizing of the main configuration window, the color picker, and a few others.
* Fix #1790 - Attack Power condition doesn't work.
* Fix #1786 - TimerBar.lua:162: TexCoord out of range

